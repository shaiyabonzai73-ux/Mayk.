package com.worldtek.mayk

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray

/** Son 20 bildirimi sadece RAM'de tutar (diske yazmaz). */
class MaykNotif : NotificationListenerService() {
    companion object {
        private val items = ArrayDeque<String>()
        fun list(): String = synchronized(items) { JSONArray(items.toList()).toString() }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val e = sbn.notification.extras
        val t = e.getCharSequence("android.title")?.toString() ?: ""
        val x = e.getCharSequence("android.text")?.toString() ?: ""
        if (t.isBlank() && x.isBlank()) return
        synchronized(items) { items.addFirst("$t: $x"); while (items.size > 20) items.removeLast() }
    }
}
