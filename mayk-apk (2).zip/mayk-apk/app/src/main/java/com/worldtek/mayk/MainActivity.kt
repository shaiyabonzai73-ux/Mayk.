package com.worldtek.mayk

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.AlarmClock
import android.provider.Settings

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var recognizer: SpeechRecognizer? = null
    private val host = "appassets.androidplatform.net"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == host) return false
                startActivity(Intent(Intent.ACTION_VIEW, r.url)) // dis baglantilar tarayicida acilir
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) {
                runOnUiThread { r.grant(r.resources) }
            }
        }
        web.addJavascriptInterface(Bridge(), "MaykNative")
        web.loadUrl("https://$host/assets/index.html")
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    }

    private fun js(fn: String, arg: String) {
        web.post { web.evaluateJavascript("window.$fn&&window.$fn(${JSONObject.quote(arg)})", null) }
    }

    private fun startListen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); js("onNativeError", "izin"); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) js("onNativeError", "bos") else js("onNativeSpeech", t)
                }
                override fun onError(e: Int) { js("onNativeError", e.toString()) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            })
        }
    }

    inner class Bridge {
        @JavascriptInterface fun listen() { runOnUiThread { startListen() } }
        @JavascriptInterface fun stop() { runOnUiThread { recognizer?.stopListening() } }

        // ---- Uygulamalar ve telefon kontrolu ----
        @JavascriptInterface fun apps(): String {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach { arr.put(JSONObject().put("n", it.loadLabel(pm).toString()).put("p", it.activityInfo.packageName)) }
            return arr.toString()
        }
        @JavascriptInterface fun openApp(p: String): Boolean {
            val i = packageManager.getLaunchIntentForPackage(p) ?: return false
            startActivity(i); return true
        }
        @JavascriptInterface fun torch(on: Boolean) {
            try {
                val cm = getSystemService(CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                cm.setTorchMode(id, on)
            } catch (e: Exception) {}
        }
        @JavascriptInterface fun volume(dir: Int) {
            (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(
                AudioManager.STREAM_MUSIC, if (dir > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        }
        @JavascriptInterface fun dial(n: String) { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + n))) }
        @JavascriptInterface fun timer(sec: Int, msg: String) {
            startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec)
                .putExtra(AlarmClock.EXTRA_MESSAGE, msg).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        }

        // ---- Erisilebilirlik (ekran okuma, dokunma, geri/ana ekran) ----
        @JavascriptInterface fun a11y(): Boolean = MaykAccess.inst != null
        @JavascriptInterface fun a11ySettings() { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        @JavascriptInterface fun screenText(): String = MaykAccess.inst?.readScreen() ?: ""
        @JavascriptInterface fun clickText(t: String): Boolean = MaykAccess.inst?.clickByText(t) ?: false
        @JavascriptInterface fun global(a: String): Boolean = MaykAccess.inst?.global(a) ?: false

        // ---- Bildirimler ----
        @JavascriptInterface fun notifOn(): Boolean =
            Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        @JavascriptInterface fun notifSettings() { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        @JavascriptInterface fun notifs(): String = MaykNotif.list()

        // ---- Mayk bellegi (en fazla 3 GB, sadece uygulamanin kendi klasoru) ----
        private fun memDir() = File(filesDir, "mayk_mem").apply { mkdirs() }
        @JavascriptInterface fun memSize(): Long = memDir().walkTopDown().filter { it.isFile }.sumOf { it.length() }
        @JavascriptInterface fun memAppend(name: String, text: String) {
            if (memSize() < 3L * 1073741824) File(memDir(), name.replace(Regex("[^a-zA-Z0-9_.-]"), "_")).appendText(text + "\n")
        }
        @JavascriptInterface fun memRead(name: String): String {
            val f = File(memDir(), name.replace(Regex("[^a-zA-Z0-9_.-]"), "_"))
            return if (f.exists()) f.readText().takeLast(4000) else ""
        }
        @JavascriptInterface fun memClear() { memDir().deleteRecursively() }
        @JavascriptInterface fun info(): String {
            val mi = ActivityManager.MemoryInfo()
            (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            val fs = StatFs(Environment.getDataDirectory().path)
            fun gb(b: Long) = String.format("%.1f GB", b / 1073741824.0)
            return JSONObject()
                .put("model", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL)
                .put("ram", gb(mi.totalMem)).put("ramFree", gb(mi.availMem))
                .put("disk", gb(fs.totalBytes)).put("diskFree", gb(fs.availableBytes)).toString()
        }
    }

    override fun onDestroy() { recognizer?.destroy(); super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() } // launcher iken geri tusu uygulamayi kapatmaz
}
