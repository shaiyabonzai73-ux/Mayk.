plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.worldtek.mayk"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.worldtek.mayk"
        minSdk = 26
        targetSdk = 34
        versionCode = 100 + (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1)
        versionName = "4.1"
    }
    signingConfigs {
        create("mayk") {
            storeFile = file("mayk.jks")
            storePassword = "mayk123456"
            keyAlias = "mayk"
            keyPassword = "mayk123456"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("mayk") }
        release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("mayk") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
