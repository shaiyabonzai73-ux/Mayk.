# Mayk v4 - Android projesi

## Telefonuna yukleme (Samsung A07)
1. Bilgisayara Android Studio kur (ucretsiz): developer.android.com/studio
2. Bu klasoru ac: File > Open > mayk-apk. "Sync" bitene kadar bekle (internet gerekir, ilk seferde birkac dakika).
3. Telefonda: Ayarlar > Telefon hakkinda > Yazilim bilgisi > "Yapi numarasi"na 7 kez dokun. Sonra Ayarlar > Gelistirici secenekleri > USB hata ayiklama'yi ac.
4. Telefonu USB ile bagla, "Izin ver" de. Android Studio'da ust cubukta telefonunu sec ve yesil Run (calistir) tusuna bas.
5. APK dosyasi istersen: Build > Build Bundle(s)/APK(s) > Build APK(s). Dosya app/build/outputs/apk/debug icinde olur.

## Mayk'i ana ekran yapmak
Ayarlar > Uygulamalar > Varsayilan uygulamalar > Ana ekran uygulamasi > Mayk.
Geri donmek icin ayni yerden "One UI Home"u sec. Once bu yolu not al.

## Icinde ne var
- app/src/main/assets/index.html : Mayk v3 arayuzu (animasyonlu logo, planlar, arkadas, arastirma, telefon sekmeleri)
- MainActivity.kt : tam ekran WebView, Turkce sesli komut (Android'in kendi konusma tanimasi), telefon bilgisi koprusu (model, RAM, depolama), mikrofon izni
- Manifest : mikrofon + internet izni, ana ekran (HOME) olabilme

## Sonraki adimlar
- Erisilebilirlik servisi (baska uygulamalari acma ve dokunma, ekran okuma)
- Bildirim erisimi ve sabah ozeti zamanlayicisi
- Kendi cevap motoru (yapay zeka baglantisi) ve 3 GB bellek klasoru

## v4 ile gelenler (izinler)
Uygulamayi actiktan sonra Telefon sekmesinde iki izin dugmesi var:
- Erisilebilirligi ac: Ayarlar'da "Mayk"i bulup ac. Ekran okuma, "dokun ...", geri/ana ekran/kilitle/ekran goruntusu icin gerekir. Sifre alanlarini okumaz.
- Bildirim erisimini ac: "bildirimlerimi oku" icin. Son 20 bildirim sadece RAM'de tutulur, diske yazilmaz.

## Sesli komut ornekleri
"Mayk WhatsApp'i ac", "feneri ac/kapat", "5 dakika sayac kur", "sesi artir/kis", "bildirimlerimi oku", "ekranda ne var", "geri", "ana ekran", "kilitle", "ekran goruntusu", "dokun Gonder", "05xxxxxxxxx ara"

## Notlar
- Mayk belleği: uygulamanin kendi klasorunde (en fazla 3 GB). Gunluk kendi notlarini gunluk.txt'ye yazar. Temizlemek icin Ayarlar > PIN (demo PIN 1234, yayindan once degistirilmeli).
- Telefon sisteminin sifre, banka ve guvenlik ekranlarini Android zaten dokunmaya kapatir; bu normaldir.
